# Module 2 — Network Topology and Ping Testing (GNS3)

Build and verify a routed network in GNS3: two Windows PCs, a Windows server, and a
Cisco 3745 router across three subnets. IP addresses assigned per the topology table,
connectivity confirmed at the command line.

## Addressing

| Host | IP address | Mask | Gateway | Router interface |
|------|-----------|------|---------|------------------|
| PC1_TestNetwork | 192.168.1.101 | 255.255.255.0 | 192.168.1.100 | Fa0/0 |
| PC2_TestNetwork | 192.168.2.101 | 255.255.255.0 | 192.168.2.100 | Fa0/1 |
| Server_TestNetwork | 192.168.3.101 | 255.255.255.0 | 192.168.3.100 | Fa1/0 |

## Contents

- `CYB_220_Module2_Assignment_Robert_Burse.docx` — the submitted deliverable.
- `assignment.md` — text version of the write-up (diffable, references figures in `media/`).
- `media/` — topology and ping-test screenshots (`image1.png`–`image9.png`).

## Ping verification

Tests followed best-practice troubleshooting order — local NIC, then local gateway,
then remote gateway, then remote host — across PC1, PC2, and the server. All returned
replies at 0% packet loss; `TTL=127` on cross-subnet pings confirms traffic was routed
between subnets.
