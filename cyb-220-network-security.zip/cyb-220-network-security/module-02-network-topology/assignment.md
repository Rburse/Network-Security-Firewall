**CYB 220 Module Two Activity**

Network Topology and Ping Testing in GNS3

**Robert Burse Jr.**

Southern New Hampshire University

CYB 220: Network Security

This document contains screenshots of the completed network topology and
the ping tests performed in the GNS3 environment. The network consists
of two Windows PCs, a Windows server, and a Cisco 3745 router configured
across three subnets. IP addresses were assigned according to the
provided topology table, and connectivity was verified at the command
line.

## **Addressing Summary**

PC1_TestNetwork --- 192.168.1.101 / 255.255.255.0 --- gateway
192.168.1.100 (Router Fa0/0)

PC2_TestNetwork --- 192.168.2.101 / 255.255.255.0 --- gateway
192.168.2.100 (Router Fa0/1)

Server_TestNetwork --- 192.168.3.101 / 255.255.255.0 --- gateway
192.168.3.100 (Router Fa1/0)

# **Part I: Network Configuration**

## **Completed Topology**

The topology below shows all four devices --- Server_TestNetwork,
Router_TestNetwork, PC1_TestNetwork, and PC2_TestNetwork --- connected
and started, with active (green) links between each host and the router.

![](media/image1.png){width="6.25in" height="3.0833333333333335in"}

*Figure 1. Completed network topology in GNS3.*

## **Router Configuration (Cisco 3745)**

The router was configured in privileged EXEC mode. Each FastEthernet
interface was assigned its gateway IP address, enabled with the no
shutdown command, and the configuration was saved with write memory.
Each interface reports \"changed state to up,\" and the write memory
command returned \[OK\].

![](media/image2.png){width="6.25in" height="3.6875in"}

## **PC2_TestNetwork Configuration**

PC2 was assigned a static IP address the same way. The ipconfig output
confirms IPv4 address 192.168.2.101 and default gateway 192.168.2.100.

![](media/image3.png){width="6.25in" height="3.3958333333333335in"}

*Figure 5. PC2_TestNetwork IP configuration.*

## **Server_TestNetwork Configuration**

The server was assigned a static IP address using netsh at an
administrator command prompt. The ipconfig output confirms IPv4 address
192.168.3.101 and default gateway 192.168.3.100.

![](media/image4.png){width="6.25in" height="3.3020833333333335in"}

*Figure 6. Server_TestNetwork IP configuration.*

# **Part I (cont.): Ping Tests --- PC1 to PC2 Communications**

These tests follow best-practice troubleshooting order, verifying
connectivity from the local host outward: first the host\'s own NIC,
then its gateway, then the remote gateway, then the remote host. All
tests were run from the PC1_TestNetwork command line and returned
replies with no packet loss.

## **D. PC1 to PC1 (self)**

![](media/image5.png){width="6.25in" height="3.8854166666666665in"}

*Figure 7. Ping from PC1 to its own address (192.168.1.101) and to its
gateway (192.168.1.100), both 0% loss.*

## **E. PC1 to PC1 Gateway**

See Figure 7 above (ping 192.168.1.100, 4 replies, 0% loss). The gateway
ping also appears alongside the remote tests in Figure 8.

## **F. PC1 to PC2 Gateway**

![](media/image6.png){width="6.25in" height="4.75in"}

*Figure 8. Pings from PC1 to its gateway (192.168.1.100), PC2\'s gateway
(192.168.2.100), and PC2 (192.168.2.101). All 0% loss.*

## **G. PC1 to PC2**

See Figure 8 above --- ping 192.168.2.101 returns 4 replies at 0% loss
with TTL=127, confirming the traffic crossed the router into the
192.168.2.0 subnet.

# **Part II: Ping Tests --- Communications Between Computers on the Network**

Each test below was run at the command line from the source device
named. Windows Firewall was disabled on each host to allow inbound ICMP
echo replies. All tests returned replies with 0% packet loss, and the
TTL=127 value confirms traffic was routed between subnets.

## **A. PC2 to PC1 and B. PC2 to Server**

![](media/image7.png){width="6.25in" height="4.71875in"}

*Figure 9. From PC2_TestNetwork: ping to PC1 (192.168.1.101) and ping to
Server (192.168.3.101), both 0% loss.*

## **C. Server to PC1 and D. Server to PC2**

![](media/image8.png){width="6.25in" height="4.5625in"}

*Figure 10. From Server_TestNetwork: ping to PC1 (192.168.1.101) and
ping to PC2 (192.168.2.101), both 0% loss.*

## **E. PC1 to Server**

![](media/image9.png){width="6.25in" height="4.364583333333333in"}

*Figure 11. From PC1_TestNetwork: ping to Server (192.168.3.101), 0%
loss, TTL=127.*

# **Acknowledgment of Generative AI Use**

In accordance with SNHU\'s generative AI usage guidelines, I acknowledge
that I used a generative AI tool (Claude, by Anthropic) as a
step-by-step troubleshooting and instructional guide while completing
this assignment. The AI tool was used to explain command syntax,
interpret error messages, and confirm the correct order of configuration
and testing steps.

All configuration, command entry, and testing in the GNS3 environment
were performed by me. All screenshots are of my own work. The AI tool
did not access the lab environment or generate any of the results shown;
it served as a learning aid comparable to a tutor or reference guide.

*Reference: Anthropic. (2026). Claude (Opus 4.8) \[Large language
model\]. https://claude.ai*
