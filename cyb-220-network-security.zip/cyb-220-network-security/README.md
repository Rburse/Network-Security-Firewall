# CYB 220 — Network Security

Coursework, labs, and assignments for **CYB 220: Network Security** at Southern New Hampshire University.

**Author:** Robert Burse Jr.

## Repository layout

Each module lives in its own folder so new work drops in without disturbing anything else:

```
cyb-220-network-security/
├── README.md                      <- this file
├── .gitignore
└── module-02-network-topology/    <- one folder per module/assignment
    ├── README.md                  <- what the module covers
    ├── *.docx                     <- the submitted deliverable
    ├── assignment.md              <- text version (diffable in Git)
    └── media/                     <- screenshots / figures
```

## Adding a new module

```bash
mkdir -p module-03-<short-name>/media
# drop your .docx, notes, and screenshots in
git add module-03-<short-name>
git commit -m "Add Module 3: <short name>"
git push
```

Keeping each module self-contained (its own `media/` and `README.md`) means you can add, rename, or remove one without touching the others.

## Modules

| Module | Topic | Folder |
|--------|-------|--------|
| 02 | Network topology & ping testing (GNS3) | [`module-02-network-topology/`](module-02-network-topology/) |
